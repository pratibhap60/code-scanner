const express = require('express');
const router = express.Router();
const multer = require('multer');
const scanController = require('../controllers/scan.controller');

// Configure multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Routes
router.post('/upload', upload.single('file'), scanController.uploadAndScan);
router.post('/code', scanController.scanCode);
router.get('/history', scanController.getScanHistory);
router.get('/result/:id', scanController.getScanResult);

module.exports = router;
