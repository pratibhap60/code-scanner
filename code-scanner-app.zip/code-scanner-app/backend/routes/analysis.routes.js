const express = require('express');
const router = express.Router();
const analysisController = require('../controllers/analysis.controller');

// Analysis routes
router.post('/security', analysisController.securityAnalysis);
router.post('/quality', analysisController.qualityAnalysis);
router.post('/documentation', analysisController.generateDocumentation);
router.post('/ai-suggestions', analysisController.getAISuggestions);

module.exports = router;
