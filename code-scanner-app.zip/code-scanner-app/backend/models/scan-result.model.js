const mongoose = require('mongoose');

const scanResultSchema = new mongoose.Schema({
  scanId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  filename: {
    type: String,
    required: true
  },
  language: {
    type: String,
    required: true
  },
  summary: {
    totalIssues: Number,
    critical: Number,
    high: Number,
    medium: Number,
    low: Number,
    codeQuality: {
      score: Number,
      grade: String
    }
  },
  codeAnalysis: {
    issues: [{
      type: String,
      severity: String,
      message: String,
      line: Number,
      category: String
    }],
    metrics: {
      totalLines: Number,
      codeLines: Number,
      commentLines: Number,
      commentRatio: String
    },
    complexity: {
      cyclomaticComplexity: mongoose.Schema.Types.Mixed,
      cognitiveComplexity: mongoose.Schema.Types.Mixed
    },
    documentation: {
      functions: Array,
      classes: Array,
      variables: Array,
      overview: String
    },
    quality: {
      score: Number,
      grade: String
    }
  },
  securityIssues: [{
    type: String,
    vulnerability: String,
    severity: String,
    message: String,
    owasp: String,
    recommendation: String,
    cwe: String
  }],
  aiSuggestions: {
    enabled: Boolean,
    suggestions: [{
      category: String,
      title: String,
      content: String,
      priority: String
    }],
    fullAnalysis: String,
    model: String,
    error: String
  }
}, {
  timestamps: true
});

// Create indexes for faster queries
scanResultSchema.index({ timestamp: -1 });
scanResultSchema.index({ 'summary.codeQuality.score': 1 });
scanResultSchema.index({ language: 1 });

module.exports = mongoose.model('ScanResult', scanResultSchema);
