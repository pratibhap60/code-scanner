class SecurityScannerService {
  async scan(code, language) {
    const vulnerabilities = [];

    vulnerabilities.push(...this.checkInjectionVulnerabilities(code, language));
    vulnerabilities.push(...this.checkAuthenticationIssues(code, language));
    vulnerabilities.push(...this.checkCryptographyIssues(code, language));
    vulnerabilities.push(...this.checkDataExposure(code, language));
    vulnerabilities.push(...this.checkInsecureDependencies(code, language));

    return vulnerabilities;
  }

  checkInjectionVulnerabilities(code, language) {
    const issues = [];

    if (language === 'javascript' || language === 'typescript') {
      // 1. SQL Injection
      if (code.match(/query\s*\([^)]*\+[^)]*\)/i) || code.match(/execute\s*\([^)]*\+[^)]*\)/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'SQL Injection',
          severity: 'critical',
          message: 'Possible SQL injection vulnerability. Use parameterized queries',
          owasp: 'A03:2021 – Injection',
          recommendation: 'Use parameterized queries or prepared statements',
          cwe: 'CWE-89'
        });
      }

      // 2. Command Injection
      if (code.match(/exec\s*\(/) || code.match(/spawn\s*\(/) || code.match(/execSync\s*\(/)) {
        issues.push({
          type: 'security',
          vulnerability: 'Command Injection',
          severity: 'critical',
          message: 'Use of exec/spawn detected. Validate and sanitize all inputs',
          owasp: 'A03:2021 – Injection',
          recommendation: 'Validate inputs and use safe alternatives or escape shell arguments',
          cwe: 'CWE-78'
        });
      }

      // 3. NoSQL Injection
      if (code.match(/\$where/i) || code.match(/find\s*\(\{[^}]*\$[^}]*\}\)/)) {
        issues.push({
          type: 'security',
          vulnerability: 'NoSQL Injection',
          severity: 'high',
          message: 'Possible NoSQL injection. Validate and sanitize query inputs',
          owasp: 'A03:2021 – Injection',
          recommendation: 'Use schema validation and avoid $where operator',
          cwe: 'CWE-943'
        });
      }

      // 4. Code Injection (eval)
      if (code.match(/\beval\s*\(/)) {
        issues.push({
          type: 'security',
          vulnerability: 'Code Injection',
          severity: 'critical',
          message: 'Use of eval() detected. This is highly dangerous and should be avoided',
          owasp: 'A03:2021 – Injection',
          recommendation: 'Never use eval(). Find alternative approaches',
          cwe: 'CWE-95'
        });
      }

      // 5. LDAP Injection
      if (code.match(/ldap.*search/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'LDAP Injection',
          severity: 'high',
          message: 'LDAP query detected. Ensure proper input validation',
          owasp: 'A03:2021 – Injection',
          recommendation: 'Escape LDAP special characters in user inputs',
          cwe: 'CWE-90'
        });
      }
    }

    return issues;
  }

  checkAuthenticationIssues(code, language) {
    const issues = [];

    if (language === 'javascript' || language === 'typescript') {
      // 1. Hardcoded credentials
      if (code.match(/password\s*=\s*['"][^'"]+['"]/i) ||
          code.match(/apiKey\s*=\s*['"][^'"]+['"]/i) ||
          code.match(/secret\s*=\s*['"][^'"]+['"]/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'Hardcoded Credentials',
          severity: 'critical',
          message: 'Hardcoded credentials detected. Use environment variables',
          owasp: 'A07:2021 – Identification and Authentication Failures',
          recommendation: 'Store credentials in environment variables or secure vaults',
          cwe: 'CWE-798'
        });
      }

      // 2. Weak password hashing
      if (code.match(/md5/i) || code.match(/sha1/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'Weak Cryptographic Hash',
          severity: 'high',
          message: 'Weak hashing algorithm (MD5/SHA1) detected',
          owasp: 'A02:2021 – Cryptographic Failures',
          recommendation: 'Use bcrypt, scrypt, or Argon2 for password hashing',
          cwe: 'CWE-327'
        });
      }

      // 3. Missing authentication
      if (code.match(/app\.(get|post|put|delete)\s*\([^)]*req,\s*res/i) &&
          !code.match(/authenticate|auth|jwt|token/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'Missing Authentication',
          severity: 'medium',
          message: 'API endpoints may be missing authentication checks',
          owasp: 'A07:2021 – Identification and Authentication Failures',
          recommendation: 'Implement proper authentication middleware',
          cwe: 'CWE-306'
        });
      }

      // 4. JWT without expiration
      if (code.match(/jwt\.sign/i) && !code.match(/expiresIn/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'JWT Without Expiration',
          severity: 'medium',
          message: 'JWT token created without expiration time',
          owasp: 'A07:2021 – Identification and Authentication Failures',
          recommendation: 'Always set expiresIn for JWT tokens',
          cwe: 'CWE-613'
        });
      }
    }

    return issues;
  }

  checkCryptographyIssues(code, language) {
    const issues = [];

    if (language === 'javascript' || language === 'typescript') {
      // 1. Weak random number generation
      if (code.match(/Math\.random\(\)/)) {
        issues.push({
          type: 'security',
          vulnerability: 'Weak Random Number Generation',
          severity: 'medium',
          message: 'Math.random() is not cryptographically secure',
          owasp: 'A02:2021 – Cryptographic Failures',
          recommendation: 'Use crypto.randomBytes() for security-sensitive operations',
          cwe: 'CWE-338'
        });
      }

      // 2. Insecure encryption
      if (code.match(/DES|RC4|ECB/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'Insecure Encryption Algorithm',
          severity: 'high',
          message: 'Insecure encryption algorithm detected',
          owasp: 'A02:2021 – Cryptographic Failures',
          recommendation: 'Use AES-256-GCM or ChaCha20-Poly1305',
          cwe: 'CWE-327'
        });
      }

      // 3. Missing encryption
      if (code.match(/http:\/\//i) && !code.match(/localhost|127\.0\.0\.1/)) {
        issues.push({
          type: 'security',
          vulnerability: 'Insecure Communication',
          severity: 'high',
          message: 'HTTP URL detected. Use HTTPS for secure communication',
          owasp: 'A02:2021 – Cryptographic Failures',
          recommendation: 'Always use HTTPS for external communications',
          cwe: 'CWE-319'
        });
      }
    }

    return issues;
  }

  checkDataExposure(code, language) {
    const issues = [];

    if (language === 'javascript' || language === 'typescript') {
      // 1. Sensitive data in logs
      if (code.match(/console\.log.*password|console\.log.*secret|console\.log.*token/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'Sensitive Data Exposure',
          severity: 'high',
          message: 'Logging sensitive data detected',
          owasp: 'A04:2021 – Insecure Design',
          recommendation: 'Never log sensitive information',
          cwe: 'CWE-532'
        });
      }

      // 2. Missing input validation
      if (code.match(/req\.(body|query|params)/i) && !code.match(/validate|sanitize|escape/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'Missing Input Validation',
          severity: 'medium',
          message: 'User input may not be validated',
          owasp: 'A03:2021 – Injection',
          recommendation: 'Always validate and sanitize user inputs',
          cwe: 'CWE-20'
        });
      }

      // 3. Directory traversal
      if (code.match(/readFile.*req\.(body|query|params)/i) ||
          code.match(/path\.join.*req\.(body|query|params)/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'Path Traversal',
          severity: 'critical',
          message: 'Possible path traversal vulnerability',
          owasp: 'A01:2021 – Broken Access Control',
          recommendation: 'Validate file paths and use path.resolve() with whitelisting',
          cwe: 'CWE-22'
        });
      }

      // 4. XXE vulnerability (XML parsing)
      if (code.match(/xml2js|xmlparser|parseXml/i)) {
        issues.push({
          type: 'security',
          vulnerability: 'XML External Entity (XXE)',
          severity: 'high',
          message: 'XML parsing detected. Ensure XXE protection is enabled',
          owasp: 'A05:2021 – Security Misconfiguration',
          recommendation: 'Disable external entity processing in XML parser',
          cwe: 'CWE-611'
        });
      }
    }

    return issues;
  }

  checkInsecureDependencies(code, language) {
    const issues = [];

    if (language === 'javascript' || language === 'typescript') {
      // 1. Deprecated packages
      const deprecatedPackages = ['request', 'node-uuid', 'gulp-util'];
      deprecatedPackages.forEach(pkg => {
        if (code.match(new RegExp(`require\\s*\\(['"]${pkg}['"]\\)`, 'i'))) {
          issues.push({
            type: 'security',
            vulnerability: 'Deprecated Package',
            severity: 'low',
            message: `Deprecated package "${pkg}" detected`,
            owasp: 'A06:2021 – Vulnerable and Outdated Components',
            recommendation: 'Update to modern alternatives',
            cwe: 'CWE-1104'
          });
        }
      });

      // 2. Unsafe regex
      if (code.match(/new RegExp\([^)]*\+[^)]*\)/)) {
        issues.push({
          type: 'security',
          vulnerability: 'ReDoS (Regular Expression Denial of Service)',
          severity: 'medium',
          message: 'Dynamic regex pattern detected. Could lead to ReDoS',
          owasp: 'A06:2021 – Vulnerable and Outdated Components',
          recommendation: 'Avoid user-controlled regex patterns',
          cwe: 'CWE-1333'
        });
      }
    }

    return issues;
  }
}

module.exports = new SecurityScannerService();
