const esprima = require('esprima');
const acorn = require('acorn');

class CodeAnalyzerService {
  async analyze(code, language) {
    const issues = [];
    const metrics = this.calculateMetrics(code);
    const patterns = this.detectAntiPatterns(code, language);
    const complexity = this.analyzeComplexity(code, language);
    const documentation = this.generateDocumentation(code, language);

    // Combine all issues
    issues.push(...patterns);
    issues.push(...this.detectBugs(code, language));
    issues.push(...this.checkCodeStyle(code, language));

    return {
      issues,
      metrics,
      complexity,
      documentation,
      quality: this.calculateQualityScore(issues, metrics, complexity)
    };
  }

  calculateMetrics(code) {
    const lines = code.split('\n');
    const nonEmptyLines = lines.filter(l => l.trim().length > 0);
    const commentLines = lines.filter(l => l.trim().startsWith('//') || l.trim().startsWith('/*') || l.trim().startsWith('*'));

    return {
      totalLines: lines.length,
      codeLines: nonEmptyLines.length - commentLines.length,
      commentLines: commentLines.length,
      commentRatio: ((commentLines.length / nonEmptyLines.length) * 100).toFixed(2)
    };
  }

  detectAntiPatterns(code, language) {
    const issues = [];

    if (language === 'javascript' || language === 'typescript') {
      // Detect common anti-patterns

      // 1. Use of var instead of let/const
      if (code.match(/\bvar\s+/g)) {
        issues.push({
          type: 'anti-pattern',
          severity: 'low',
          message: 'Use of "var" detected. Consider using "let" or "const"',
          line: this.findLineNumber(code, /\bvar\s+/),
          category: 'best-practices'
        });
      }

      // 2. Console.log in production
      const consoleMatches = code.match(/console\.(log|debug|info)/g);
      if (consoleMatches && consoleMatches.length > 0) {
        issues.push({
          type: 'anti-pattern',
          severity: 'low',
          message: `Found ${consoleMatches.length} console statements. Remove before production`,
          line: this.findLineNumber(code, /console\.(log|debug|info)/),
          category: 'best-practices'
        });
      }

      // 3. Callback hell / pyramid of doom
      const callbackDepth = this.detectCallbackHell(code);
      if (callbackDepth > 3) {
        issues.push({
          type: 'anti-pattern',
          severity: 'medium',
          message: `Deep callback nesting detected (depth: ${callbackDepth}). Consider using Promises or async/await`,
          category: 'maintainability'
        });
      }

      // 4. Long functions
      const longFunctions = this.detectLongFunctions(code);
      longFunctions.forEach(func => {
        issues.push({
          type: 'code-smell',
          severity: 'medium',
          message: `Function "${func.name}" is too long (${func.lines} lines). Consider breaking it down`,
          line: func.line,
          category: 'maintainability'
        });
      });

      // 5. Magic numbers
      const magicNumbers = code.match(/(?<![a-zA-Z_$])\d{3,}(?![a-zA-Z_$])/g);
      if (magicNumbers && magicNumbers.length > 0) {
        issues.push({
          type: 'code-smell',
          severity: 'low',
          message: 'Magic numbers detected. Consider using named constants',
          category: 'readability'
        });
      }

      // 6. == instead of ===
      if (code.match(/[^=!]==(?!=)/g)) {
        issues.push({
          type: 'anti-pattern',
          severity: 'medium',
          message: 'Use of "==" detected. Use "===" for strict equality',
          line: this.findLineNumber(code, /[^=!]==(?!=)/),
          category: 'best-practices'
        });
      }

      // 7. Nested ternary operators
      if (code.match(/\?[^:]+\?[^:]+:/)) {
        issues.push({
          type: 'anti-pattern',
          severity: 'medium',
          message: 'Nested ternary operators detected. Consider using if-else for readability',
          category: 'readability'
        });
      }
    }

    return issues;
  }

  detectBugs(code, language) {
    const issues = [];

    if (language === 'javascript' || language === 'typescript') {
      // 1. Undefined variables
      if (code.match(/\bundefined\b/g)) {
        issues.push({
          type: 'potential-bug',
          severity: 'medium',
          message: 'Explicit use of undefined detected',
          category: 'bugs'
        });
      }

      // 2. Assignment in condition
      if (code.match(/if\s*\([^)]*=[^=]/)) {
        issues.push({
          type: 'potential-bug',
          severity: 'high',
          message: 'Possible assignment in conditional. Did you mean "==="?',
          line: this.findLineNumber(code, /if\s*\([^)]*=[^=]/),
          category: 'bugs'
        });
      }

      // 3. Empty catch blocks
      if (code.match(/catch\s*\([^)]*\)\s*\{\s*\}/)) {
        issues.push({
          type: 'potential-bug',
          severity: 'medium',
          message: 'Empty catch block detected. Handle errors properly',
          line: this.findLineNumber(code, /catch\s*\([^)]*\)\s*\{\s*\}/),
          category: 'error-handling'
        });
      }

      // 4. Unreachable code after return
      const unreachablePattern = /return[^;]*;[\s\n]+(?!}|$)[^\n]/;
      if (code.match(unreachablePattern)) {
        issues.push({
          type: 'bug',
          severity: 'high',
          message: 'Unreachable code after return statement',
          category: 'bugs'
        });
      }

      // 5. Missing await on async calls
      if (code.match(/\basync\s+\w+/)) {
        const asyncWithoutAwait = code.match(/\.\w+\(\)(?!\s*\.then)(?!\s*\.catch)/g);
        if (asyncWithoutAwait) {
          issues.push({
            type: 'potential-bug',
            severity: 'medium',
            message: 'Possible missing await on async function call',
            category: 'async'
          });
        }
      }
    }

    return issues;
  }

  checkCodeStyle(code, language) {
    const issues = [];

    // 1. Long lines
    const lines = code.split('\n');
    lines.forEach((line, index) => {
      if (line.length > 120) {
        issues.push({
          type: 'style',
          severity: 'low',
          message: `Line ${index + 1} exceeds 120 characters (${line.length} characters)`,
          line: index + 1,
          category: 'formatting'
        });
      }
    });

    // 2. Missing semicolons (if applicable)
    if (language === 'javascript' || language === 'typescript') {
      const missingSemicolons = code.match(/[^;\s]\n/g);
      if (missingSemicolons && missingSemicolons.length > 5) {
        issues.push({
          type: 'style',
          severity: 'low',
          message: 'Inconsistent semicolon usage detected',
          category: 'formatting'
        });
      }
    }

    // 3. Inconsistent indentation
    const indentations = lines
      .filter(l => l.trim().length > 0)
      .map(l => l.match(/^\s*/)[0].length);

    const hasSpaces = indentations.some(i => i % 2 === 0 && i > 0);
    const hasTabs = code.includes('\t');

    if (hasSpaces && hasTabs) {
      issues.push({
        type: 'style',
        severity: 'low',
        message: 'Mixed spaces and tabs for indentation',
        category: 'formatting'
      });
    }

    return issues;
  }

  analyzeComplexity(code, language) {
    if (language !== 'javascript' && language !== 'typescript') {
      return { cyclomaticComplexity: 'N/A', cognitiveComplexity: 'N/A' };
    }

    try {
      const ast = esprima.parseScript(code, { tolerant: true });
      const complexity = this.calculateCyclomaticComplexity(ast);

      return {
        cyclomaticComplexity: complexity,
        cognitiveComplexity: this.calculateCognitiveComplexity(code)
      };
    } catch (error) {
      return { cyclomaticComplexity: 'Error', cognitiveComplexity: 'Error', error: error.message };
    }
  }

  calculateCyclomaticComplexity(ast) {
    let complexity = 1;

    const traverse = (node) => {
      if (!node) return;

      if (node.type === 'IfStatement' ||
          node.type === 'WhileStatement' ||
          node.type === 'ForStatement' ||
          node.type === 'SwitchCase' ||
          node.type === 'ConditionalExpression' ||
          node.type === 'LogicalExpression' && node.operator === '||' ||
          node.type === 'LogicalExpression' && node.operator === '&&') {
        complexity++;
      }

      for (const key in node) {
        if (node[key] && typeof node[key] === 'object') {
          if (Array.isArray(node[key])) {
            node[key].forEach(traverse);
          } else {
            traverse(node[key]);
          }
        }
      }
    };

    traverse(ast);
    return complexity;
  }

  calculateCognitiveComplexity(code) {
    let complexity = 0;

    // Count nesting and control structures
    const controlStructures = code.match(/\b(if|else|for|while|switch|catch)\b/g);
    complexity += controlStructures ? controlStructures.length : 0;

    // Add points for nesting
    const nestingLevel = this.detectCallbackHell(code);
    complexity += nestingLevel * 2;

    return complexity;
  }

  detectCallbackHell(code) {
    let maxDepth = 0;
    let currentDepth = 0;

    for (let i = 0; i < code.length; i++) {
      if (code[i] === '{') {
        currentDepth++;
        maxDepth = Math.max(maxDepth, currentDepth);
      } else if (code[i] === '}') {
        currentDepth--;
      }
    }

    return maxDepth;
  }

  detectLongFunctions(code) {
    const longFunctions = [];
    const functionPattern = /function\s+(\w+)\s*\([^)]*\)\s*{/g;

    let match;
    while ((match = functionPattern.exec(code)) !== null) {
      const startIndex = match.index;
      const functionName = match[1];

      // Find the end of the function
      let braceCount = 1;
      let endIndex = startIndex + match[0].length;

      while (braceCount > 0 && endIndex < code.length) {
        if (code[endIndex] === '{') braceCount++;
        if (code[endIndex] === '}') braceCount--;
        endIndex++;
      }

      const functionCode = code.substring(startIndex, endIndex);
      const lines = functionCode.split('\n').length;

      if (lines > 50) {
        longFunctions.push({
          name: functionName,
          lines: lines,
          line: this.getLineNumber(code, startIndex)
        });
      }
    }

    return longFunctions;
  }

  generateDocumentation(code, language) {
    const docs = {
      functions: [],
      classes: [],
      variables: [],
      overview: ''
    };

    if (language === 'javascript' || language === 'typescript') {
      try {
        // Extract functions
        const functionMatches = code.matchAll(/(?:function\s+(\w+)|const\s+(\w+)\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=]+)\s*=>)/g);
        for (const match of functionMatches) {
          const funcName = match[1] || match[2];
          docs.functions.push({
            name: funcName,
            type: 'function',
            description: `Function: ${funcName}`,
            line: this.findLineNumber(code, new RegExp(funcName))
          });
        }

        // Extract classes
        const classMatches = code.matchAll(/class\s+(\w+)/g);
        for (const match of classMatches) {
          docs.classes.push({
            name: match[1],
            type: 'class',
            description: `Class: ${match[1]}`
          });
        }

        // Generate overview
        docs.overview = `Code contains ${docs.functions.length} functions and ${docs.classes.length} classes.`;
      } catch (error) {
        docs.overview = 'Error generating documentation';
      }
    }

    return docs;
  }

  calculateQualityScore(issues, metrics, complexity) {
    let score = 100;

    // Deduct points for issues
    issues.forEach(issue => {
      switch (issue.severity) {
        case 'critical': score -= 15; break;
        case 'high': score -= 10; break;
        case 'medium': score -= 5; break;
        case 'low': score -= 2; break;
      }
    });

    // Deduct for high complexity
    if (typeof complexity.cyclomaticComplexity === 'number' && complexity.cyclomaticComplexity > 10) {
      score -= (complexity.cyclomaticComplexity - 10) * 2;
    }

    // Bonus for good comment ratio
    const commentRatio = parseFloat(metrics.commentRatio);
    if (commentRatio >= 10 && commentRatio <= 30) {
      score += 5;
    }

    return {
      score: Math.max(0, Math.min(100, score)),
      grade: this.getGrade(score)
    };
  }

  getGrade(score) {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  }

  findLineNumber(code, pattern) {
    const match = code.match(pattern);
    if (!match) return 1;

    const beforeMatch = code.substring(0, match.index);
    return beforeMatch.split('\n').length;
  }

  getLineNumber(code, index) {
    return code.substring(0, index).split('\n').length;
  }
}

module.exports = new CodeAnalyzerService();
