const OpenAI = require('openai');

class AIService {
  constructor() {
    this.openai = null;
    this.initializeOpenAI();
  }

  initializeOpenAI() {
    if (process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
    } else {
      console.warn('⚠️  OpenAI API key not found. AI features will be limited.');
    }
  }

  async getCodeSuggestions(code, language, context = '') {
    if (!this.openai) {
      return {
        enabled: false,
        message: 'OpenAI API key not configured',
        suggestions: []
      };
    }

    try {
      const prompt = this.buildPrompt(code, language, context);

      const completion = await this.openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: [
          {
            role: 'system',
            content: 'You are an expert code reviewer and software architect. Analyze code and provide actionable suggestions for improvements, optimizations, and best practices.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 2000
      });

      const analysis = completion.choices[0].message.content;

      return {
        enabled: true,
        suggestions: this.parseAISuggestions(analysis),
        fullAnalysis: analysis,
        model: 'gpt-4-turbo-preview'
      };
    } catch (error) {
      console.error('OpenAI API error:', error.message);
      return {
        enabled: false,
        error: error.message,
        suggestions: []
      };
    }
  }

  buildPrompt(code, language, context) {
    return `Analyze the following ${language} code and provide detailed suggestions:

${context ? `Context: ${context}\n` : ''}
\`\`\`${language}
${code}
\`\`\`

Please provide:
1. **Code Quality Assessment**: Overall quality and maintainability score
2. **Performance Optimizations**: Specific areas that can be optimized
3. **Security Concerns**: Any potential security vulnerabilities
4. **Best Practices**: Recommendations for following ${language} best practices
5. **Refactoring Suggestions**: Specific code refactoring recommendations
6. **Design Patterns**: Applicable design patterns that could improve the code
7. **Testing Recommendations**: Suggestions for test coverage

Format your response with clear sections and actionable suggestions.`;
  }

  parseAISuggestions(analysis) {
    const suggestions = [];

    // Parse the AI response and extract structured suggestions
    const sections = [
      'Code Quality Assessment',
      'Performance Optimizations',
      'Security Concerns',
      'Best Practices',
      'Refactoring Suggestions',
      'Design Patterns',
      'Testing Recommendations'
    ];

    sections.forEach(section => {
      const regex = new RegExp(`\\*\\*${section}\\*\\*:?([^*]+)(?=\\*\\*|$)`, 'i');
      const match = analysis.match(regex);

      if (match && match[1]) {
        const content = match[1].trim();
        suggestions.push({
          category: section.toLowerCase().replace(/ /g, '-'),
          title: section,
          content: content,
          priority: this.determinePriority(section, content)
        });
      }
    });

    return suggestions;
  }

  determinePriority(section, content) {
    const lowerContent = content.toLowerCase();

    if (section.includes('Security') ||
        lowerContent.includes('critical') ||
        lowerContent.includes('vulnerability') ||
        lowerContent.includes('dangerous')) {
      return 'high';
    }

    if (section.includes('Performance') ||
        section.includes('Best Practices') ||
        lowerContent.includes('important') ||
        lowerContent.includes('should')) {
      return 'medium';
    }

    return 'low';
  }

  async explainCode(code, language) {
    if (!this.openai) {
      return { error: 'OpenAI API key not configured' };
    }

    try {
      const completion = await this.openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful programming tutor. Explain code in a clear, concise manner.'
          },
          {
            role: 'user',
            content: `Explain what this ${language} code does:\n\n\`\`\`${language}\n${code}\n\`\`\``
          }
        ],
        temperature: 0.5,
        max_tokens: 1000
      });

      return {
        explanation: completion.choices[0].message.content
      };
    } catch (error) {
      console.error('OpenAI API error:', error.message);
      return { error: error.message };
    }
  }

  async suggestRefactoring(code, language, issue) {
    if (!this.openai) {
      return { error: 'OpenAI API key not configured' };
    }

    try {
      const completion = await this.openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: [
          {
            role: 'system',
            content: 'You are an expert code refactoring assistant. Provide specific, actionable refactoring suggestions with code examples.'
          },
          {
            role: 'user',
            content: `The following ${language} code has this issue: "${issue}"\n\nCode:\n\`\`\`${language}\n${code}\n\`\`\`\n\nProvide a refactored version with explanation.`
          }
        ],
        temperature: 0.7,
        max_tokens: 1500
      });

      return {
        refactoring: completion.choices[0].message.content
      };
    } catch (error) {
      console.error('OpenAI API error:', error.message);
      return { error: error.message };
    }
  }
}

module.exports = new AIService();
