const securityScanner = require('../services/security-scanner.service');
const codeAnalyzer = require('../services/code-analyzer.service');
const aiService = require('../services/ai.service');

class AnalysisController {
  async securityAnalysis(req, res) {
    try {
      const { code, language } = req.body;
      const issues = await securityScanner.scan(code, language);
      res.json({ issues });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async qualityAnalysis(req, res) {
    try {
      const { code, language } = req.body;
      const analysis = await codeAnalyzer.analyze(code, language);
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async generateDocumentation(req, res) {
    try {
      const { code, language } = req.body;
      const docs = await codeAnalyzer.generateDocumentation(code, language);
      res.json({ documentation: docs });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getAISuggestions(req, res) {
    try {
      const { code, language, context } = req.body;
      const suggestions = await aiService.getCodeSuggestions(code, language, context);
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new AnalysisController();
