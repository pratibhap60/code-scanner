const codeAnalyzer = require('../services/code-analyzer.service');
const securityScanner = require('../services/security-scanner.service');
const aiService = require('../services/ai.service');
const ScanResult = require('../models/scan-result.model');

class ScanController {
  constructor() {
    // Bind methods to preserve 'this' context
    this.uploadAndScan = this.uploadAndScan.bind(this);
    this.scanCode = this.scanCode.bind(this);
    this.getScanHistory = this.getScanHistory.bind(this);
    this.getScanResult = this.getScanResult.bind(this);
  }

  async uploadAndScan(req, res) {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      const code = req.file.buffer.toString('utf-8');
      const filename = req.file.originalname;
      const language = detectLanguage(filename);

      const result = await this.performFullScan(code, language, filename);

      res.json(result);
    } catch (error) {
      console.error('Upload scan error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async scanCode(req, res) {
    try {
      const { code, language, filename } = req.body;

      if (!code) {
        return res.status(400).json({ error: 'No code provided' });
      }

      const result = await this.performFullScan(code, language || 'javascript', filename || 'unnamed.js');

      res.json(result);
    } catch (error) {
      console.error('Code scan error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async performFullScan(code, language, filename) {
    const scanId = generateScanId();

    // Run all analyses
    const [
      codeAnalysis,
      securityIssues,
      aiSuggestions
    ] = await Promise.all([
      codeAnalyzer.analyze(code, language),
      securityScanner.scan(code, language),
      aiService.getCodeSuggestions(code, language)
    ]);

    // Provide defaults for undefined values
    const safeCodeAnalysis = codeAnalysis || { issues: [], quality: { score: 0 }, documentation: null };
    const safeSecurityIssues = Array.isArray(securityIssues) ? securityIssues : [];
    const safeAiSuggestions = aiSuggestions || {};

    // Safely access nested properties
    const codeIssues = Array.isArray(safeCodeAnalysis.issues) ? safeCodeAnalysis.issues : [];
    const qualityScore = safeCodeAnalysis.quality?.score ?? 0;
    const allIssues = [...codeIssues, ...safeSecurityIssues];

    const result = {
      scanId,
      timestamp: new Date(),
      filename,
      language,
      summary: {
        totalIssues: codeIssues.length + safeSecurityIssues.length,
        critical: safeSecurityIssues.filter(i => i?.severity === 'critical').length,
        high: safeSecurityIssues.filter(i => i?.severity === 'high').length,
        medium: allIssues.filter(i => i?.severity === 'medium').length,
        low: allIssues.filter(i => i?.severity === 'low').length,
        codeQuality: qualityScore
      },
      codeAnalysis: safeCodeAnalysis,
      securityIssues: safeSecurityIssues,
      aiSuggestions: safeAiSuggestions,
      documentation: safeCodeAnalysis.documentation || null
    };

    // Save to database if MongoDB is connected
    try {
      if (ScanResult) {
        await ScanResult.create(result);
      }
    } catch (dbError) {
      console.warn('Database save failed:', dbError.message);
    }

    return result;
  }

  async getScanHistory(req, res) {
    try {
      const limit = parseInt(req.query.limit) || 20;
      const history = await ScanResult.find()
        .sort({ timestamp: -1 })
        .limit(limit)
        .select('-codeAnalysis.code -aiSuggestions.fullAnalysis');

      res.json(history);
    } catch (error) {
      console.error('Get history error:', error);
      res.status(500).json({ error: error.message });
    }
  }

  async getScanResult(req, res) {
    try {
      const result = await ScanResult.findOne({ scanId: req.params.id });

      if (!result) {
        return res.status(404).json({ error: 'Scan result not found' });
      }

      res.json(result);
    } catch (error) {
      console.error('Get result error:', error);
      res.status(500).json({ error: error.message });
    }
  }
}

function detectLanguage(filename) {
  const ext = filename.split('.').pop().toLowerCase();
  const langMap = {
    'js': 'javascript',
    'jsx': 'javascript',
    'ts': 'typescript',
    'tsx': 'typescript',
    'py': 'python',
    'java': 'java',
    'cpp': 'cpp',
    'c': 'c',
    'cs': 'csharp',
    'go': 'go',
    'rb': 'ruby',
    'php': 'php'
  };
  return langMap[ext] || 'javascript';
}

function generateScanId() {
  return `scan_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

module.exports = new ScanController();
