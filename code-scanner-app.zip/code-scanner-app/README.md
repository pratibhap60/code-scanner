# 🔍 Code Scanner - AI-Powered Code Review Engine

A comprehensive web-based code analysis tool that combines static analysis, security scanning, and AI-powered suggestions to help you write better code.

## ✨ Features

### 🐛 **Auto Code Analysis**
- Static code analysis for multiple languages
- Detection of common bugs and anti-patterns
- Code complexity metrics (Cyclomatic & Cognitive)
- Code quality scoring with letter grades

### 🛡️ **Security Scanning**
- OWASP Top 10 vulnerability detection
- Security best practices validation
- CWE (Common Weakness Enumeration) mapping
- Detailed remediation recommendations

### 🧠 **AI-Powered Suggestions**
- OpenAI GPT-4 integration for intelligent code review
- Refactoring suggestions
- Performance optimization recommendations
- Design pattern suggestions
- Testing recommendations

### 📄 **Auto-Documentation**
- Automatic code documentation generation
- Function and class extraction
- Code structure analysis

### 📊 **Comprehensive Reporting**
- Beautiful, interactive dashboard
- Detailed issue breakdowns
- Historical scan tracking
- Export capabilities

## 🏗️ Architecture

```
code-scanner-app/
├── backend/                 # Node.js/Express API
│   ├── controllers/        # Request handlers
│   ├── services/           # Business logic
│   │   ├── code-analyzer.service.js
│   │   ├── security-scanner.service.js
│   │   └── ai.service.js
│   ├── models/             # Database models
│   ├── routes/             # API routes
│   └── server.js           # Main server file
│
└── frontend/               # Angular application
    └── src/
        ├── app/
        │   ├── components/ # Reusable components
        │   ├── pages/      # Page components
        │   └── services/   # API services
        └── styles.css      # Global styles
```

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm
- MongoDB (optional, for storing scan history)
- OpenAI API Key (for AI features)

### Backend Setup

1. Navigate to the backend directory:
```bash
cd code-scanner-app/backend
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file from the example:
```bash
cp .env.example .env
```

4. Configure your environment variables in `.env`:
```env
PORT=3000
OPENAI_API_KEY=your_openai_api_key_here
MONGODB_URI=mongodb://localhost:27017/code-scanner
NODE_ENV=development
```

5. Start the backend server:
```bash
npm run dev
```

The backend will be running at `http://localhost:3000`

### Frontend Setup

1. Navigate to the frontend directory:
```bash
cd code-scanner-app/frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

The frontend will be running at `http://localhost:4200`

## 📖 Usage

### 1. Access the Dashboard
Open your browser and navigate to `http://localhost:4200`

### 2. Create a New Scan
- Click "New Scan" or "Start New Scan"
- Choose between:
  - **Paste Code**: Copy and paste your code directly
  - **Upload File**: Upload a source code file

### 3. View Results
Results are organized into tabs:
- **Security**: Security vulnerabilities with OWASP mapping
- **Code Quality**: Metrics, complexity, and code issues
- **AI Suggestions**: Intelligent recommendations from GPT-4
- **Documentation**: Auto-generated code documentation

### 4. Browse History
- View all previous scans
- Filter and search through scan history
- Re-examine past analysis results

## 🔧 API Endpoints

### Scan Endpoints

```bash
POST /api/scan/code
Body: { code: string, language: string, filename: string }
```

```bash
POST /api/scan/upload
Body: FormData with file
```

```bash
GET /api/scan/history?limit=20
```

```bash
GET /api/scan/result/:id
```

### Analysis Endpoints

```bash
POST /api/analysis/security
Body: { code: string, language: string }
```

```bash
POST /api/analysis/quality
Body: { code: string, language: string }
```

```bash
POST /api/analysis/ai-suggestions
Body: { code: string, language: string, context?: string }
```

```bash
POST /api/analysis/documentation
Body: { code: string, language: string }
```

## 🎨 Supported Languages

- JavaScript (.js)
- TypeScript (.ts, .tsx)
- Python (.py)
- Java (.java)
- C++ (.cpp)
- C# (.cs)
- Go (.go)
- Ruby (.rb)
- PHP (.php)

## 🛡️ Security Checks

The scanner detects:
- SQL Injection vulnerabilities
- Command Injection risks
- NoSQL Injection
- Cross-Site Scripting (XSS)
- Hardcoded credentials
- Weak cryptographic algorithms
- Path traversal vulnerabilities
- Insecure dependencies
- And more...

## 🐛 Bug Detection

Identifies common issues:
- Undefined variable usage
- Assignment in conditionals
- Empty catch blocks
- Unreachable code
- Missing await on async calls
- Use of `var` instead of `let`/`const`
- Magic numbers
- Callback hell
- Long functions
- And more...

## 📊 Code Quality Metrics

- **Lines of Code**: Total, code, and comment lines
- **Comment Ratio**: Percentage of comments
- **Cyclomatic Complexity**: Control flow complexity
- **Cognitive Complexity**: How difficult code is to understand
- **Quality Score**: 0-100 score with letter grade (A-F)

## 🧪 Testing

### Backend Tests
```bash
cd backend
npm test
```

### Frontend Tests
```bash
cd frontend
npm test
```

## 🔑 Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `PORT` | Backend server port | No (default: 3000) |
| `OPENAI_API_KEY` | OpenAI API key for AI features | Yes (for AI) |
| `MONGODB_URI` | MongoDB connection string | No |
| `NODE_ENV` | Environment (development/production) | No |

## 🚧 Troubleshooting

### Backend won't start
- Ensure Node.js 18+ is installed
- Check that port 3000 is available
- Verify all dependencies are installed

### Frontend won't start
- Ensure Angular CLI is installed globally: `npm install -g @angular/cli`
- Check that port 4200 is available
- Clear node_modules and reinstall: `rm -rf node_modules && npm install`

### AI features not working
- Verify your OpenAI API key is set in `.env`
- Check your OpenAI account has available credits
- Ensure the key has proper permissions

### Database connection issues
- Ensure MongoDB is running
- Verify the connection string in `.env`
- The app works without MongoDB (scans won't be saved)

## 📝 License

MIT License - Feel free to use this project for personal or commercial purposes.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📧 Support

For issues, questions, or suggestions, please open an issue on the repository.

## 🌟 Features Coming Soon

- [ ] Multi-language support for UI
- [ ] PDF export of scan results
- [ ] Team collaboration features
- [ ] CI/CD integration
- [ ] VSCode extension
- [ ] Custom rule configuration
- [ ] Performance benchmarking
- [ ] Code coverage analysis

---

Built with ❤️ using Angular, Node.js, and OpenAI GPT-4
