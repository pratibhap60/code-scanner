# 🚀 Setup Guide - Code Scanner

Complete setup instructions for the Code Scanner application.

## 📋 Prerequisites

Before you begin, ensure you have the following installed:

1. **Node.js** (v18 or higher)
   - Download from: https://nodejs.org/
   - Verify installation: `node --version`

2. **npm** (comes with Node.js)
   - Verify installation: `npm --version`

3. **Angular CLI** (optional but recommended)
   ```bash
   npm install -g @angular/cli
   ```

4. **MongoDB** (optional - for scan history persistence)
   - Download from: https://www.mongodb.com/try/download/community
   - Or use MongoDB Atlas (cloud): https://www.mongodb.com/cloud/atlas

5. **OpenAI API Key** (required for AI features)
   - Sign up at: https://platform.openai.com/
   - Create an API key in your dashboard

## 🔧 Step-by-Step Installation

### Step 1: Backend Setup

1. Open a terminal/command prompt

2. Navigate to the backend directory:
   ```bash
   cd code-scanner-app/backend
   ```

3. Install all dependencies:
   ```bash
   npm install
   ```

4. Configure environment variables:
   - The `.env` file already exists with default values
   - **IMPORTANT**: Replace `your_openai_api_key_here` with your actual OpenAI API key

   Open `backend/.env` and update:
   ```env
   PORT=3000
   OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   MONGODB_URI=mongodb://localhost:27017/code-scanner
   NODE_ENV=development
   ```

5. Start the backend server:
   ```bash
   npm start
   ```

   Or for development with auto-reload:
   ```bash
   npm run dev
   ```

6. You should see:
   ```
   🚀 Code Scanner Backend running on port 3000
   ```

   If MongoDB is connected:
   ```
   ✅ MongoDB connected
   ```

### Step 2: Frontend Setup

1. Open a **NEW** terminal/command prompt (keep the backend running)

2. Navigate to the frontend directory:
   ```bash
   cd code-scanner-app/frontend
   ```

3. Install all dependencies:
   ```bash
   npm install
   ```

4. Start the frontend development server:
   ```bash
   npm start
   ```

   Or if you have Angular CLI installed:
   ```bash
   ng serve
   ```

5. You should see:
   ```
   Angular Live Development Server is listening on localhost:4200
   ```

6. Open your browser and navigate to:
   ```
   http://localhost:4200
   ```

## ✅ Verification

### Test Backend
Open a new terminal and run:
```bash
curl http://localhost:3000/health
```

Expected response:
```json
{"status":"OK","timestamp":"2024-01-15T10:30:00.000Z"}
```

### Test Frontend
- Your browser should show the Code Scanner dashboard
- You should see "Code Scanner" in the header
- Navigation links: Dashboard, New Scan, History

## 🎯 First Scan

1. Click "New Scan" or "Start New Scan"

2. Paste this sample code:
   ```javascript
   function getUserData() {
     var password = "admin123";
     var query = "SELECT * FROM users WHERE id = " + userId;
     eval(userInput);
     console.log(password);
   }
   ```

3. Click "Analyze Code"

4. View the results showing:
   - Security vulnerabilities (hardcoded password, SQL injection, eval usage)
   - Code quality issues (use of var, console.log)
   - AI suggestions (if OpenAI key is configured)

## 🔍 Without MongoDB

If you don't want to install MongoDB:
1. The application will still work perfectly
2. Scans won't be saved to history
3. You'll see a warning in the backend logs (this is normal)
4. To use scan history, install MongoDB or use MongoDB Atlas

## 🔑 Getting OpenAI API Key

1. Go to https://platform.openai.com/
2. Sign up or log in
3. Navigate to API Keys section
4. Click "Create new secret key"
5. Copy the key (starts with `sk-`)
6. Paste it in `backend/.env`
7. Restart the backend server

**Note**: OpenAI API usage requires payment. Check pricing at https://openai.com/pricing

## 🆘 Common Issues

### Issue: Port 3000 already in use
**Solution**:
- Stop other applications using port 3000
- Or change `PORT` in `backend/.env` to a different port (e.g., 3001)

### Issue: Port 4200 already in use
**Solution**:
```bash
ng serve --port 4201
```

### Issue: "Cannot find module" errors
**Solution**:
```bash
# Delete node_modules and reinstall
rm -rf node_modules
npm install
```

### Issue: OpenAI API errors
**Solutions**:
- Verify your API key is correct
- Check your OpenAI account has available credits
- Ensure the key is properly set in `.env`
- Restart the backend after updating `.env`

### Issue: MongoDB connection failed
**Solutions**:
- Ensure MongoDB is running: `mongod`
- Or comment out the MongoDB lines in `backend/server.js` (lines 16-21)
- Or use MongoDB Atlas and update the connection string

### Issue: CORS errors in browser
**Solutions**:
- Ensure backend is running on port 3000
- Check `cors` is enabled in `backend/server.js`
- Clear browser cache

## 🌐 Production Deployment

### Backend
1. Set `NODE_ENV=production` in `.env`
2. Use a process manager like PM2:
   ```bash
   npm install -g pm2
   pm2 start server.js
   ```

### Frontend
1. Build for production:
   ```bash
   ng build --configuration production
   ```
2. Serve the `dist/` folder with nginx or any static server

### Environment Variables for Production
- Use proper MongoDB connection string
- Protect your OpenAI API key
- Use HTTPS for secure communication
- Set proper CORS origins

## 📦 Docker Setup (Optional)

If you prefer Docker:

1. Backend Dockerfile:
   ```dockerfile
   FROM node:18
   WORKDIR /app
   COPY package*.json ./
   RUN npm install
   COPY . .
   EXPOSE 3000
   CMD ["npm", "start"]
   ```

2. Run:
   ```bash
   docker build -t code-scanner-backend .
   docker run -p 3000:3000 --env-file .env code-scanner-backend
   ```

## 🎉 You're All Set!

Your Code Scanner application is now ready to use. Start analyzing code and improving code quality!

## 📚 Next Steps

- Read the main README.md for detailed usage instructions
- Explore the API documentation
- Customize analysis rules
- Integrate with your CI/CD pipeline

## 💡 Tips

1. **Save API costs**: OpenAI API calls cost money. Consider implementing caching or rate limiting.

2. **Improve performance**: Add Redis for caching scan results.

3. **Customize rules**: Modify services in `backend/services/` to add custom analysis rules.

4. **Add more languages**: Extend language support by updating the parsers and analyzers.

---

Need help? Open an issue or contact support!
