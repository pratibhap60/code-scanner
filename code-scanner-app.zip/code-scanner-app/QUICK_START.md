# ⚡ Quick Start - Get Running in 5 Minutes

## 🎯 Prerequisites Check

Before starting, verify you have:
- [ ] Node.js 18+ installed (`node --version`)
- [ ] npm installed (`npm --version`)
- [ ] OpenAI API key (get from https://platform.openai.com/)

## 🚀 Installation Steps

### 1️⃣ Backend Setup (2 minutes)

Open Terminal/Command Prompt:

```bash
# Navigate to backend
cd code-scanner-app/backend

# Install dependencies
npm install

# This will take 1-2 minutes
```

**Configure OpenAI Key**:
- Open `backend/.env` file
- Replace `your_openai_api_key_here` with your actual API key
- Save the file

**Start Backend**:
```bash
npm start
```

✅ You should see: `🚀 Code Scanner Backend running on port 3000`

### 2️⃣ Frontend Setup (2 minutes)

Open a **NEW** Terminal/Command Prompt (keep backend running):

```bash
# Navigate to frontend
cd code-scanner-app/frontend

# Install dependencies
npm install

# This will take 1-2 minutes
```

**Start Frontend**:
```bash
npm start
```

✅ You should see: `Angular Live Development Server is listening on localhost:4200`

### 3️⃣ Open in Browser

Navigate to: **http://localhost:4200**

## 🧪 Test It Out

1. Click **"Start New Scan"** or **"New Scan"**

2. Select **"📝 Paste Code"**

3. Paste this test code:
```javascript
function processUser(userId) {
  var password = "admin123";
  var query = "SELECT * FROM users WHERE id = " + userId;

  if (userId = 1) {
    console.log("Processing user:", password);
    eval("delete user." + userId);
  }

  return query;
}
```

4. Click **"Analyze Code"**

5. Wait 5-10 seconds for results

## 📊 Expected Results

You should see:
- 🛡️ **Security Issues**: 5-7 critical vulnerabilities
  - Hardcoded credentials
  - SQL injection
  - Code injection (eval)
  - Sensitive data logging

- 📊 **Code Quality Issues**: 3-4 issues
  - Use of var
  - Assignment in condition
  - Console.log usage

- 🧠 **AI Suggestions**: Intelligent recommendations from GPT-4

- 📄 **Documentation**: Auto-generated function details

## 🎉 Success!

Your Code Scanner is now fully operational!

## ⚙️ Configuration (Optional)

### Without MongoDB
The app works fine without MongoDB. Scans just won't be saved to history.

### With MongoDB
If you want to save scan history:

1. Install MongoDB: https://www.mongodb.com/try/download/community
2. Start MongoDB: `mongod`
3. Backend will automatically connect

## 🆘 Troubleshooting

### Backend won't start
```bash
# Check if port 3000 is in use
# Windows
netstat -ano | findstr :3000

# Mac/Linux
lsof -i :3000

# Kill the process or change PORT in .env
```

### Frontend won't start
```bash
# Try a different port
npm start -- --port 4201
```

### OpenAI not working
- Verify your API key is correct
- Check OpenAI account has credits
- Restart backend after updating .env

### "Cannot find module" error
```bash
# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

## 📚 Next Steps

- Read **README.md** for detailed documentation
- Read **SETUP.md** for advanced setup options
- Read **PROJECT_OVERVIEW.md** to understand architecture
- Customize analysis rules in `backend/services/`
- Add more languages support
- Integrate with your CI/CD pipeline

## 🎯 Common Use Cases

### Scan a file
1. Go to "New Scan"
2. Select "📁 Upload File"
3. Drag and drop your file
4. Click "Analyze File"

### View history
1. Click "History" in navigation
2. See all previous scans
3. Click any scan to view details

### Get AI suggestions
1. After scanning, go to "🧠 AI Suggestions" tab
2. Read GPT-4 powered recommendations
3. Implement suggested improvements

## 💡 Tips

- **Save API costs**: Cache results, implement rate limiting
- **Better results**: Write descriptive function names for better AI analysis
- **Security**: Never commit real API keys to version control
- **Performance**: For large files, consider running analysis in background

---

Need more help? Check out the other documentation files or open an issue!

**Happy Scanning! 🔍✨**
