import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService, ScanResult } from '../../services/api.service';

@Component({
  selector: 'app-scanner',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="scanner">
      <div class="container">
        <h1>New Code Scan</h1>
        <p class="subtitle">Upload a file or paste code to analyze</p>

        <div class="scan-options">
          <button
            class="option-btn"
            [class.active]="scanMode === 'paste'"
            (click)="scanMode = 'paste'">
            📝 Paste Code
          </button>
          <button
            class="option-btn"
            [class.active]="scanMode === 'upload'"
            (click)="scanMode = 'upload'">
            📁 Upload File
          </button>
        </div>

        <div class="card scan-card">
          <!-- Paste Code Mode -->
          <div *ngIf="scanMode === 'paste'" class="paste-mode">
            <div class="form-group">
              <label>Language</label>
              <select [(ngModel)]="language" class="select-input">
                <option value="javascript">JavaScript</option>
                <option value="typescript">TypeScript</option>
                <option value="python">Python</option>
                <option value="java">Java</option>
                <option value="cpp">C++</option>
                <option value="csharp">C#</option>
                <option value="go">Go</option>
                <option value="ruby">Ruby</option>
                <option value="php">PHP</option>
              </select>
            </div>
            <div class="form-group">
              <label>Filename (optional)</label>
              <input
                type="text"
                [(ngModel)]="filename"
                placeholder="example.js"
                class="text-input">
            </div>
            <div class="form-group">
              <label>Code</label>
              <textarea
                [(ngModel)]="code"
                placeholder="Paste your code here..."
                class="code-textarea"
                rows="15"></textarea>
            </div>
            <button
              class="btn btn-primary"
              [disabled]="!code || scanning"
              (click)="scanPastedCode()">
              {{ scanning ? 'Scanning...' : 'Analyze Code' }}
            </button>
          </div>

          <!-- Upload File Mode -->
          <div *ngIf="scanMode === 'upload'" class="upload-mode">
            <div
              class="upload-zone"
              [class.dragover]="isDragging"
              (drop)="onDrop($event)"
              (dragover)="onDragOver($event)"
              (dragleave)="onDragLeave($event)">
              <div class="upload-content">
                <div class="upload-icon">📄</div>
                <p class="upload-text">Drag and drop a file here or</p>
                <input
                  type="file"
                  #fileInput
                  (change)="onFileSelected($event)"
                  style="display: none">
                <button
                  class="btn btn-secondary"
                  (click)="fileInput.click()">
                  Browse Files
                </button>
                <p class="upload-info">
                  Supported: .js, .ts, .py, .java, .cpp, .cs, .go, .rb, .php
                </p>
              </div>
            </div>
            <div *ngIf="selectedFile" class="selected-file">
              <span>📎 {{ selectedFile.name }}</span>
              <button class="btn btn-secondary" (click)="removeFile()">Remove</button>
            </div>
            <button
              class="btn btn-primary"
              [disabled]="!selectedFile || scanning"
              (click)="scanUploadedFile()">
              {{ scanning ? 'Scanning...' : 'Analyze File' }}
            </button>
          </div>

          <!-- Loading State -->
          <div *ngIf="scanning" class="loading">
            <div class="spinner"></div>
            <p>Analyzing your code...</p>
            <p class="loading-detail">This may take a few moments</p>
          </div>

          <!-- Error State -->
          <div *ngIf="error" class="alert alert-error">
            <strong>Error:</strong> {{ error }}
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .scanner {
      padding: 40px 0;
    }

    .subtitle {
      color: var(--text-secondary);
      margin-bottom: 32px;
    }

    .scan-options {
      display: flex;
      gap: 16px;
      margin-bottom: 24px;
    }

    .option-btn {
      flex: 1;
      padding: 16px;
      border: 2px solid var(--border-color);
      background: white;
      border-radius: 12px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }

    .option-btn:hover {
      border-color: var(--primary-color);
      background: #f9fafb;
    }

    .option-btn.active {
      border-color: var(--primary-color);
      background: #eef2ff;
      color: var(--primary-color);
    }

    .scan-card {
      max-width: 800px;
      margin: 0 auto;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      margin-bottom: 8px;
      color: var(--text-primary);
    }

    .text-input,
    .select-input {
      width: 100%;
      padding: 12px;
      border: 2px solid var(--border-color);
      border-radius: 8px;
      font-size: 14px;
      transition: border-color 0.2s;
    }

    .text-input:focus,
    .select-input:focus {
      outline: none;
      border-color: var(--primary-color);
    }

    .code-textarea {
      width: 100%;
      padding: 16px;
      border: 2px solid var(--border-color);
      border-radius: 8px;
      font-family: 'Fira Code', monospace;
      font-size: 14px;
      resize: vertical;
      transition: border-color 0.2s;
    }

    .code-textarea:focus {
      outline: none;
      border-color: var(--primary-color);
    }

    .upload-zone {
      border: 3px dashed var(--border-color);
      border-radius: 12px;
      padding: 60px 20px;
      text-align: center;
      transition: all 0.3s;
      margin-bottom: 20px;
    }

    .upload-zone.dragover {
      border-color: var(--primary-color);
      background: #eef2ff;
    }

    .upload-content {
      max-width: 400px;
      margin: 0 auto;
    }

    .upload-icon {
      font-size: 64px;
      margin-bottom: 16px;
    }

    .upload-text {
      color: var(--text-secondary);
      margin-bottom: 16px;
    }

    .upload-info {
      font-size: 12px;
      color: var(--text-secondary);
      margin-top: 16px;
    }

    .selected-file {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px;
      background: #f9fafb;
      border-radius: 8px;
      margin-bottom: 20px;
    }

    .loading-detail {
      font-size: 14px;
      color: var(--text-secondary);
      margin-top: 8px;
    }

    .btn[disabled] {
      opacity: 0.5;
      cursor: not-allowed;
    }
  `]
})
export class ScannerComponent {
  scanMode: 'paste' | 'upload' = 'paste';
  code = '';
  language = 'javascript';
  filename = '';
  selectedFile: File | null = null;
  scanning = false;
  error = '';
  isDragging = false;

  constructor(
    private apiService: ApiService,
    private router: Router
  ) {}

  scanPastedCode() {
    this.scanning = true;
    this.error = '';

    const fname = this.filename || `code.${this.getExtension(this.language)}`;

    this.apiService.scanCode(this.code, this.language, fname).subscribe({
      next: (result) => {
        this.scanning = false;
        this.router.navigate(['/results', result.scanId]);
      },
      error: (err) => {
        this.scanning = false;
        this.error = err.error?.error || 'Failed to scan code';
      }
    });
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
    }
  }

  scanUploadedFile() {
    if (!this.selectedFile) return;

    this.scanning = true;
    this.error = '';

    this.apiService.uploadFile(this.selectedFile).subscribe({
      next: (result) => {
        this.scanning = false;
        this.router.navigate(['/results', result.scanId]);
      },
      error: (err) => {
        this.scanning = false;
        this.error = err.error?.error || 'Failed to scan file';
      }
    });
  }

  removeFile() {
    this.selectedFile = null;
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = true;
  }

  onDragLeave(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;

    const files = event.dataTransfer?.files;
    if (files && files.length > 0) {
      this.selectedFile = files[0];
    }
  }

  getExtension(language: string): string {
    const extensionMap: { [key: string]: string } = {
      'javascript': 'js',
      'typescript': 'ts',
      'python': 'py',
      'java': 'java',
      'cpp': 'cpp',
      'csharp': 'cs',
      'go': 'go',
      'ruby': 'rb',
      'php': 'php'
    };
    return extensionMap[language] || 'txt';
  }
}
