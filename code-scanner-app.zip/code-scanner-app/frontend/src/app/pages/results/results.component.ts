import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ApiService, ScanResult } from '../../services/api.service';

@Component({
  selector: 'app-results',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="results" *ngIf="result">
      <div class="container">
        <!-- Header -->
        <div class="results-header">
          <div>
            <h1>{{ result.filename }}</h1>
            <p class="scan-meta">
              <span class="badge badge-info">{{ result.language }}</span>
              <span>Scanned: {{ result.timestamp | date:'medium' }}</span>
            </p>
          </div>
          <div class="quality-score-large">
            <div class="score-circle-large"
                 [class.score-high]="result.summary.codeQuality.score >= 80"
                 [class.score-medium]="result.summary.codeQuality.score >= 60 && result.summary.codeQuality.score < 80"
                 [class.score-low]="result.summary.codeQuality.score < 60">
              {{ result.summary.codeQuality.score }}
            </div>
            <div class="score-details">
              <div class="quality-grade">Grade {{ result.summary.codeQuality.grade }}</div>
              <div class="quality-label">Code Quality</div>
            </div>
          </div>
        </div>

        <!-- Summary Cards -->
        <div class="summary-cards grid grid-4">
          <div class="card stat-card">
            <div class="stat-label">Total Issues</div>
            <div class="stat-value">{{ result.summary.totalIssues }}</div>
          </div>
          <div class="card stat-card critical-card">
            <div class="stat-label">Critical</div>
            <div class="stat-value">{{ result.summary.critical }}</div>
          </div>
          <div class="card stat-card high-card">
            <div class="stat-label">High</div>
            <div class="stat-value">{{ result.summary.high }}</div>
          </div>
          <div class="card stat-card medium-card">
            <div class="stat-label">Medium</div>
            <div class="stat-value">{{ result.summary.medium }}</div>
          </div>
        </div>

        <!-- Tabs -->
        <div class="tabs">
          <button
            *ngFor="let tab of tabs"
            class="tab-btn"
            [class.active]="activeTab === tab.id"
            (click)="activeTab = tab.id">
            {{ tab.icon }} {{ tab.label }}
            <span class="tab-count" *ngIf="tab.count">{{ tab.count }}</span>
          </button>
        </div>

        <!-- Tab Content -->
        <div class="tab-content">
          <!-- Security Issues Tab -->
          <div *ngIf="activeTab === 'security'" class="card">
            <h2>🛡️ Security Vulnerabilities</h2>
            <div *ngIf="result.securityIssues.length === 0" class="empty-state">
              ✅ No security issues found!
            </div>
            <div *ngFor="let issue of result.securityIssues" class="issue-item">
              <div class="issue-header">
                <span class="badge" [ngClass]="'badge-' + issue.severity">
                  {{ issue.severity.toUpperCase() }}
                </span>
                <h3>{{ issue.vulnerability }}</h3>
              </div>
              <p class="issue-message">{{ issue.message }}</p>
              <div class="issue-details">
                <div><strong>OWASP:</strong> {{ issue.owasp }}</div>
                <div><strong>CWE:</strong> {{ issue.cwe }}</div>
                <div class="recommendation">
                  <strong>💡 Recommendation:</strong> {{ issue.recommendation }}
                </div>
              </div>
            </div>
          </div>

          <!-- Code Quality Tab -->
          <div *ngIf="activeTab === 'quality'" class="card">
            <h2>📊 Code Quality Analysis</h2>

            <!-- Metrics -->
            <div class="metrics-grid grid grid-3">
              <div class="metric-card">
                <div class="metric-label">Total Lines</div>
                <div class="metric-value">{{ result.codeAnalysis.metrics.totalLines }}</div>
              </div>
              <div class="metric-card">
                <div class="metric-label">Code Lines</div>
                <div class="metric-value">{{ result.codeAnalysis.metrics.codeLines }}</div>
              </div>
              <div class="metric-card">
                <div class="metric-label">Comment Ratio</div>
                <div class="metric-value">{{ result.codeAnalysis.metrics.commentRatio }}%</div>
              </div>
              <div class="metric-card">
                <div class="metric-label">Cyclomatic Complexity</div>
                <div class="metric-value">{{ result.codeAnalysis.complexity.cyclomaticComplexity }}</div>
              </div>
              <div class="metric-card">
                <div class="metric-label">Cognitive Complexity</div>
                <div class="metric-value">{{ result.codeAnalysis.complexity.cognitiveComplexity }}</div>
              </div>
            </div>

            <!-- Issues -->
            <h3>Issues Found</h3>
            <div *ngIf="result.codeAnalysis.issues.length === 0" class="empty-state">
              ✅ No code quality issues found!
            </div>
            <div *ngFor="let issue of result.codeAnalysis.issues" class="issue-item">
              <div class="issue-header">
                <span class="badge" [ngClass]="'badge-' + issue.severity">
                  {{ issue.severity }}
                </span>
                <h4>{{ issue.message }}</h4>
              </div>
              <div class="issue-meta">
                <span *ngIf="issue.line">Line {{ issue.line }}</span>
                <span class="issue-category">{{ issue.category }}</span>
              </div>
            </div>
          </div>

          <!-- AI Suggestions Tab -->
          <div *ngIf="activeTab === 'ai'" class="card">
            <h2>🧠 AI-Powered Suggestions</h2>
            <div *ngIf="!result.aiSuggestions.enabled" class="alert alert-warning">
              AI suggestions are not enabled. Please configure your OpenAI API key.
            </div>
            <div *ngIf="result.aiSuggestions.error" class="alert alert-error">
              Error: {{ result.aiSuggestions.error }}
            </div>
            <div *ngIf="result.aiSuggestions.enabled && result.aiSuggestions.suggestions">
              <div *ngFor="let suggestion of result.aiSuggestions.suggestions" class="suggestion-item">
                <div class="suggestion-header">
                  <h3>{{ suggestion.title }}</h3>
                  <span class="badge" [ngClass]="'badge-' + suggestion.priority">
                    {{ suggestion.priority }} priority
                  </span>
                </div>
                <div class="suggestion-content">{{ suggestion.content }}</div>
              </div>
            </div>
          </div>

          <!-- Documentation Tab -->
          <div *ngIf="activeTab === 'docs'" class="card">
            <h2>📄 Auto-Generated Documentation</h2>
            <div class="docs-section">
              <h3>Overview</h3>
              <p>{{ result.codeAnalysis.documentation.overview }}</p>
            </div>
            <div class="docs-section" *ngIf="result.codeAnalysis.documentation.functions.length > 0">
              <h3>Functions ({{ result.codeAnalysis.documentation.functions.length }})</h3>
              <div class="docs-list">
                <div *ngFor="let func of result.codeAnalysis.documentation.functions" class="docs-item">
                  <code>{{ func.name }}</code>
                  <span *ngIf="func.line" class="docs-line">Line {{ func.line }}</span>
                </div>
              </div>
            </div>
            <div class="docs-section" *ngIf="result.codeAnalysis.documentation.classes.length > 0">
              <h3>Classes ({{ result.codeAnalysis.documentation.classes.length }})</h3>
              <div class="docs-list">
                <div *ngFor="let cls of result.codeAnalysis.documentation.classes" class="docs-item">
                  <code>{{ cls.name }}</code>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div *ngIf="loading" class="loading">
      <div class="spinner"></div>
      <p>Loading results...</p>
    </div>

    <div *ngIf="error" class="container">
      <div class="alert alert-error">{{ error }}</div>
    </div>
  `,
  styles: [`
    .results {
      padding: 40px 0;
    }

    .results-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 32px;
    }

    .results-header h1 {
      margin-bottom: 8px;
    }

    .scan-meta {
      display: flex;
      gap: 16px;
      align-items: center;
      color: var(--text-secondary);
    }

    .quality-score-large {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .score-circle-large {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 36px;
      font-weight: 700;
      color: white;
    }

    .score-details {
      text-align: left;
    }

    .quality-grade {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 4px;
    }

    .quality-label {
      color: var(--text-secondary);
    }

    .summary-cards {
      margin-bottom: 32px;
    }

    .stat-card {
      text-align: center;
      padding: 20px;
    }

    .stat-label {
      color: var(--text-secondary);
      font-size: 14px;
      margin-bottom: 8px;
    }

    .stat-value {
      font-size: 36px;
      font-weight: 700;
      color: var(--primary-color);
    }

    .critical-card .stat-value {
      color: var(--danger-color);
    }

    .high-card .stat-value {
      color: var(--warning-color);
    }

    .medium-card .stat-value {
      color: #f59e0b;
    }

    .tabs {
      display: flex;
      gap: 8px;
      margin-bottom: 24px;
      border-bottom: 2px solid var(--border-color);
    }

    .tab-btn {
      padding: 12px 24px;
      border: none;
      background: none;
      cursor: pointer;
      font-weight: 600;
      color: var(--text-secondary);
      border-bottom: 3px solid transparent;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .tab-btn:hover {
      color: var(--primary-color);
    }

    .tab-btn.active {
      color: var(--primary-color);
      border-bottom-color: var(--primary-color);
    }

    .tab-count {
      background: var(--border-color);
      padding: 2px 8px;
      border-radius: 10px;
      font-size: 12px;
    }

    .tab-btn.active .tab-count {
      background: var(--primary-color);
      color: white;
    }

    .tab-content {
      min-height: 400px;
    }

    .empty-state {
      text-align: center;
      padding: 60px 20px;
      color: var(--text-secondary);
      font-size: 18px;
    }

    .issue-item {
      padding: 20px;
      border: 1px solid var(--border-color);
      border-radius: 8px;
      margin-bottom: 16px;
    }

    .issue-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 12px;
    }

    .issue-header h3,
    .issue-header h4 {
      margin: 0;
      font-size: 16px;
    }

    .issue-message {
      color: var(--text-secondary);
      margin-bottom: 12px;
    }

    .issue-details {
      display: flex;
      flex-direction: column;
      gap: 8px;
      font-size: 14px;
    }

    .recommendation {
      margin-top: 8px;
      padding: 12px;
      background: #f0fdf4;
      border-left: 3px solid var(--secondary-color);
      border-radius: 4px;
    }

    .issue-meta {
      display: flex;
      gap: 16px;
      font-size: 14px;
      color: var(--text-secondary);
    }

    .issue-category {
      text-transform: capitalize;
    }

    .metrics-grid {
      margin: 24px 0;
    }

    .metric-card {
      text-align: center;
      padding: 20px;
      background: #f9fafb;
      border-radius: 8px;
    }

    .metric-label {
      font-size: 14px;
      color: var(--text-secondary);
      margin-bottom: 8px;
    }

    .metric-value {
      font-size: 32px;
      font-weight: 700;
      color: var(--primary-color);
    }

    .suggestion-item {
      margin-bottom: 24px;
      padding: 20px;
      background: #f9fafb;
      border-radius: 8px;
    }

    .suggestion-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }

    .suggestion-header h3 {
      margin: 0;
    }

    .suggestion-content {
      color: var(--text-secondary);
      white-space: pre-wrap;
      line-height: 1.8;
    }

    .docs-section {
      margin-bottom: 32px;
    }

    .docs-section h3 {
      color: var(--primary-color);
      margin-bottom: 16px;
    }

    .docs-list {
      display: grid;
      gap: 12px;
    }

    .docs-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px;
      background: #f9fafb;
      border-radius: 6px;
    }

    .docs-item code {
      background: #1e293b;
      color: #e2e8f0;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 14px;
    }

    .docs-line {
      font-size: 12px;
      color: var(--text-secondary);
    }
  `]
})
export class ResultsComponent implements OnInit {
  result: ScanResult | null = null;
  loading = true;
  error = '';
  activeTab = 'security';
  tabs: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private apiService: ApiService
  ) {}

  ngOnInit() {
    const scanId = this.route.snapshot.paramMap.get('id');
    if (scanId) {
      this.loadResults(scanId);
    }
  }

  loadResults(scanId: string) {
    this.apiService.getScanResult(scanId).subscribe({
      next: (result) => {
        this.result = result;
        this.loading = false;
        this.setupTabs();
      },
      error: (err) => {
        this.error = err.error?.error || 'Failed to load results';
        this.loading = false;
      }
    });
  }

  setupTabs() {
    if (!this.result) return;

    this.tabs = [
      {
        id: 'security',
        label: 'Security',
        icon: '🛡️',
        count: this.result.securityIssues.length
      },
      {
        id: 'quality',
        label: 'Code Quality',
        icon: '📊',
        count: this.result.codeAnalysis.issues.length
      },
      {
        id: 'ai',
        label: 'AI Suggestions',
        icon: '🧠',
        count: this.result.aiSuggestions.suggestions?.length || 0
      },
      {
        id: 'docs',
        label: 'Documentation',
        icon: '📄',
        count: null
      }
    ];
  }
}
