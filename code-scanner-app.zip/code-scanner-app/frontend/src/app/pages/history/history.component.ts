import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ApiService, ScanResult } from '../../services/api.service';

@Component({
  selector: 'app-history',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="history">
      <div class="container">
        <div class="header">
          <h1>Scan History</h1>
          <button class="btn btn-primary" (click)="goToScanner()">
            + New Scan
          </button>
        </div>

        <div *ngIf="loading" class="loading">
          <div class="spinner"></div>
          <p>Loading history...</p>
        </div>

        <div *ngIf="!loading && scans.length === 0" class="empty-state card">
          <div class="empty-icon">📋</div>
          <h2>No scans yet</h2>
          <p>Start by creating your first code scan</p>
          <button class="btn btn-primary" (click)="goToScanner()">
            Create First Scan
          </button>
        </div>

        <div *ngIf="!loading && scans.length > 0" class="history-list">
          <div class="card scan-item" *ngFor="let scan of scans" (click)="viewScan(scan.scanId)">
            <div class="scan-main">
              <div class="scan-info">
                <h3>{{ scan.filename }}</h3>
                <div class="scan-meta">
                  <span class="badge badge-info">{{ scan.language }}</span>
                  <span class="scan-date">{{ scan.timestamp | date:'medium' }}</span>
                </div>
              </div>
              <div class="scan-score">
                <div class="score-circle"
                     [class.score-high]="scan.summary.codeQuality.score >= 80"
                     [class.score-medium]="scan.summary.codeQuality.score >= 60 && scan.summary.codeQuality.score < 80"
                     [class.score-low]="scan.summary.codeQuality.score < 60">
                  {{ scan.summary.codeQuality.score }}
                </div>
                <span class="grade-label">Grade {{ scan.summary.codeQuality.grade }}</span>
              </div>
            </div>

            <div class="scan-summary">
              <div class="summary-item">
                <span class="summary-label">Total Issues:</span>
                <span class="summary-value">{{ scan.summary.totalIssues }}</span>
              </div>
              <div class="issue-badges">
                <span class="badge badge-critical" *ngIf="scan.summary.critical > 0">
                  {{ scan.summary.critical }} Critical
                </span>
                <span class="badge badge-high" *ngIf="scan.summary.high > 0">
                  {{ scan.summary.high }} High
                </span>
                <span class="badge badge-medium" *ngIf="scan.summary.medium > 0">
                  {{ scan.summary.medium }} Medium
                </span>
                <span class="badge badge-low" *ngIf="scan.summary.low > 0">
                  {{ scan.summary.low }} Low
                </span>
              </div>
            </div>
          </div>
        </div>

        <div *ngIf="error" class="alert alert-error">
          {{ error }}
        </div>
      </div>
    </div>
  `,
  styles: [`
    .history {
      padding: 40px 0;
      min-height: 80vh;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 32px;
    }

    .empty-state {
      text-align: center;
      padding: 80px 20px;
    }

    .empty-icon {
      font-size: 80px;
      margin-bottom: 24px;
    }

    .empty-state h2 {
      color: var(--text-primary);
      margin-bottom: 12px;
    }

    .empty-state p {
      color: var(--text-secondary);
      margin-bottom: 24px;
    }

    .history-list {
      display: grid;
      gap: 16px;
    }

    .scan-item {
      cursor: pointer;
      transition: all 0.2s;
      padding: 24px;
    }

    .scan-item:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-lg);
    }

    .scan-main {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 16px;
      padding-bottom: 16px;
      border-bottom: 1px solid var(--border-color);
    }

    .scan-info h3 {
      margin-bottom: 8px;
      color: var(--text-primary);
    }

    .scan-meta {
      display: flex;
      gap: 12px;
      align-items: center;
    }

    .scan-date {
      font-size: 14px;
      color: var(--text-secondary);
    }

    .scan-score {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
    }

    .score-circle {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      font-weight: 700;
      color: white;
    }

    .score-high {
      background: var(--secondary-color);
    }

    .score-medium {
      background: var(--warning-color);
    }

    .score-low {
      background: var(--danger-color);
    }

    .grade-label {
      font-size: 12px;
      color: var(--text-secondary);
      font-weight: 600;
    }

    .scan-summary {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
    }

    .summary-item {
      display: flex;
      gap: 8px;
      align-items: center;
    }

    .summary-label {
      font-weight: 600;
      color: var(--text-secondary);
    }

    .summary-value {
      font-weight: 700;
      color: var(--primary-color);
      font-size: 18px;
    }

    .issue-badges {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
  `]
})
export class HistoryComponent implements OnInit {
  scans: ScanResult[] = [];
  loading = true;
  error = '';

  constructor(
    private apiService: ApiService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadHistory();
  }

  loadHistory() {
    this.apiService.getScanHistory(50).subscribe({
      next: (scans) => {
        this.scans = scans;
        this.loading = false;
      },
      error: (err) => {
        this.error = err.error?.error || 'Failed to load history';
        this.loading = false;
      }
    });
  }

  viewScan(scanId: string) {
    this.router.navigate(['/results', scanId]);
  }

  goToScanner() {
    this.router.navigate(['/scanner']);
  }
}
