import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ApiService, ScanResult } from '../../services/api.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="dashboard">
      <div class="container">
        <div class="hero">
          <h1>🔍 AI-Powered Code Scanner</h1>
          <p class="subtitle">
            Comprehensive code analysis with bug detection, security scanning,
            and AI-powered suggestions
          </p>
          <button class="btn btn-primary btn-large" (click)="goToScanner()">
            Start New Scan
          </button>
        </div>

        <div class="features grid grid-3">
          <div class="feature-card card">
            <div class="feature-icon">🐛</div>
            <h3>Bug Detection</h3>
            <p>Automatically detect common bugs, anti-patterns, and code smells</p>
          </div>
          <div class="feature-card card">
            <div class="feature-icon">🛡️</div>
            <h3>Security Scanning</h3>
            <p>Identify security vulnerabilities and OWASP Top 10 issues</p>
          </div>
          <div class="feature-card card">
            <div class="feature-icon">🧠</div>
            <h3>AI Suggestions</h3>
            <p>Get intelligent recommendations powered by OpenAI</p>
          </div>
          <div class="feature-card card">
            <div class="feature-icon">📊</div>
            <h3>Code Quality</h3>
            <p>Measure cyclomatic complexity and code maintainability</p>
          </div>
          <div class="feature-card card">
            <div class="feature-icon">📄</div>
            <h3>Auto Documentation</h3>
            <p>Generate documentation from your code automatically</p>
          </div>
          <div class="feature-card card">
            <div class="feature-icon">🔄</div>
            <h3>Refactoring Tips</h3>
            <p>Receive actionable suggestions to improve your code</p>
          </div>
        </div>

        <div class="stats-section" *ngIf="recentScans.length > 0">
          <h2>Recent Scans</h2>
          <div class="grid grid-2">
            <div class="card" *ngFor="let scan of recentScans">
              <div class="scan-header">
                <h3>{{ scan.filename }}</h3>
                <span class="badge badge-info">{{ scan.language }}</span>
              </div>
              <div class="scan-summary">
                <div class="quality-score">
                  <div class="score-circle" [class.score-high]="scan.summary.codeQuality.score >= 80"
                       [class.score-medium]="scan.summary.codeQuality.score >= 60 && scan.summary.codeQuality.score < 80"
                       [class.score-low]="scan.summary.codeQuality.score < 60">
                    {{ scan.summary.codeQuality.score }}
                  </div>
                  <div>
                    <div class="quality-grade">Grade: {{ scan.summary.codeQuality.grade }}</div>
                    <div class="scan-date">{{ scan.timestamp | date:'short' }}</div>
                  </div>
                </div>
                <div class="issue-counts">
                  <span class="badge badge-critical" *ngIf="scan.summary.critical > 0">
                    {{ scan.summary.critical }} Critical
                  </span>
                  <span class="badge badge-high" *ngIf="scan.summary.high > 0">
                    {{ scan.summary.high }} High
                  </span>
                  <span class="badge badge-medium" *ngIf="scan.summary.medium > 0">
                    {{ scan.summary.medium }} Medium
                  </span>
                  <span class="badge badge-low" *ngIf="scan.summary.low > 0">
                    {{ scan.summary.low }} Low
                  </span>
                </div>
              </div>
              <button class="btn btn-secondary" (click)="viewResults(scan.scanId)">
                View Details
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard {
      padding: 40px 0;
    }

    .hero {
      text-align: center;
      padding: 60px 0;
    }

    .hero h1 {
      font-size: 48px;
      margin-bottom: 16px;
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .subtitle {
      font-size: 20px;
      color: var(--text-secondary);
      max-width: 600px;
      margin: 0 auto 32px;
    }

    .btn-large {
      font-size: 18px;
      padding: 16px 40px;
    }

    .features {
      margin: 60px 0;
    }

    .feature-card {
      text-align: center;
      transition: transform 0.2s;
    }

    .feature-card:hover {
      transform: translateY(-4px);
    }

    .feature-icon {
      font-size: 48px;
      margin-bottom: 16px;
    }

    .feature-card h3 {
      color: var(--primary-color);
      margin-bottom: 12px;
    }

    .feature-card p {
      color: var(--text-secondary);
      font-size: 14px;
    }

    .stats-section {
      margin-top: 60px;
    }

    .scan-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }

    .scan-header h3 {
      margin: 0;
      font-size: 18px;
    }

    .scan-summary {
      margin-bottom: 20px;
    }

    .quality-score {
      display: flex;
      align-items: center;
      gap: 16px;
      margin-bottom: 16px;
    }

    .score-circle {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      font-weight: 700;
      color: white;
    }

    .score-high {
      background: var(--secondary-color);
    }

    .score-medium {
      background: var(--warning-color);
    }

    .score-low {
      background: var(--danger-color);
    }

    .quality-grade {
      font-weight: 600;
      margin-bottom: 4px;
    }

    .scan-date {
      font-size: 12px;
      color: var(--text-secondary);
    }

    .issue-counts {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }
  `]
})
export class DashboardComponent implements OnInit {
  recentScans: ScanResult[] = [];

  constructor(
    private apiService: ApiService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadRecentScans();
  }

  loadRecentScans() {
    this.apiService.getScanHistory(4).subscribe({
      next: (scans) => {
        this.recentScans = scans;
      },
      error: (err) => {
        console.error('Error loading recent scans:', err);
      }
    });
  }

  goToScanner() {
    this.router.navigate(['/scanner']);
  }

  viewResults(scanId: string) {
    this.router.navigate(['/results', scanId]);
  }
}
