import { Routes } from '@angular/router';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ScannerComponent } from './pages/scanner/scanner.component';
import { ResultsComponent } from './pages/results/results.component';
import { HistoryComponent } from './pages/history/history.component';

export const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'scanner', component: ScannerComponent },
  { path: 'results/:id', component: ResultsComponent },
  { path: 'history', component: HistoryComponent }
];
