import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ScanResult {
  scanId: string;
  timestamp: Date;
  filename: string;
  language: string;
  summary: {
    totalIssues: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
    codeQuality: {
      score: number;
      grade: string;
    };
  };
  codeAnalysis: any;
  securityIssues: any[];
  aiSuggestions: any;
  documentation: any;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  scanCode(code: string, language: string, filename: string): Observable<ScanResult> {
    return this.http.post<ScanResult>(`${this.apiUrl}/scan/code`, {
      code,
      language,
      filename
    });
  }

  uploadFile(file: File): Observable<ScanResult> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<ScanResult>(`${this.apiUrl}/scan/upload`, formData);
  }

  getScanHistory(limit: number = 20): Observable<ScanResult[]> {
    return this.http.get<ScanResult[]>(`${this.apiUrl}/scan/history?limit=${limit}`);
  }

  getScanResult(id: string): Observable<ScanResult> {
    return this.http.get<ScanResult>(`${this.apiUrl}/scan/result/${id}`);
  }

  getSecurityAnalysis(code: string, language: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/analysis/security`, { code, language });
  }

  getQualityAnalysis(code: string, language: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/analysis/quality`, { code, language });
  }

  generateDocumentation(code: string, language: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/analysis/documentation`, { code, language });
  }

  getAISuggestions(code: string, language: string, context?: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/analysis/ai-suggestions`, { code, language, context });
  }
}
