import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <header class="header">
      <div class="container">
        <nav class="nav">
          <div class="logo">
            <span class="logo-icon">🔍</span>
            <span class="logo-text">Code Scanner</span>
          </div>
          <ul class="nav-links">
            <li>
              <a routerLink="/dashboard" routerLinkActive="active">Dashboard</a>
            </li>
            <li>
              <a routerLink="/scanner" routerLinkActive="active">New Scan</a>
            </li>
            <li>
              <a routerLink="/history" routerLinkActive="active">History</a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  `,
  styles: [`
    .header {
      background: white;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 0;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 24px;
      font-weight: 700;
      color: var(--primary-color);
    }

    .logo-icon {
      font-size: 32px;
    }

    .nav-links {
      display: flex;
      list-style: none;
      gap: 32px;
    }

    .nav-links a {
      text-decoration: none;
      color: var(--text-secondary);
      font-weight: 500;
      padding: 8px 16px;
      border-radius: 6px;
      transition: all 0.2s;
    }

    .nav-links a:hover {
      color: var(--primary-color);
      background: #f3f4f6;
    }

    .nav-links a.active {
      color: var(--primary-color);
      background: #eef2ff;
    }
  `]
})
export class HeaderComponent {}
