# Context Engineering — Code Scanner (Code Smell Detection)

This folder contains context- and prompt-engineering artifacts to power the Code Smell Detection Engine and its Visual Studio Code extension integration.

Purpose
- Provide tested prompt templates, message schemas, and few-shot examples for each detector.
- Explain how to chunk and send code to the AI back-end, and how to convert AI outputs into VS Code diagnostics and code actions.

Files
- `PROMPTS.md` — General system/user prompt templates, input/output schemas, token & chunking guidance.
- `DETECTOR_PROMPTS.md` — Focused prompts and few-shot examples for each code-smell detector in the feature list.
- `CONVERSATION_TEMPLATES.md` — Example API payloads, streaming vs batch strategies, error handling and retries.
- `USAGE.md` — Integration notes for the VS Code extension and mapping AI results to diagnostics/code actions.
- `EXAMPLES.md` — Example code snippets and expected AI outputs (JSON) for quick testing.

How to use
1. Read `PROMPTS.md` and implement the base system prompt in the backend `ai.service.js` (or in the extension if using the model directly).
2. Use `DETECTOR_PROMPTS.md` to call per-detector prompts for higher precision or to run detectors in parallel.
3. Convert AI JSON outputs (see `CONVERSATION_TEMPLATES.md`) into VS Code `Diagnostic` objects with severity mapping.

Notes
- All prompts include explicit output schema to avoid hallucination. Use strict JSON-only responses from the model and validate the JSON.
- For large files, use the chunking guidance in `PROMPTS.md` to keep context within token limits.
- These docs are implementation-oriented; copy & paste the templates into your backend handlers and test with the `EXAMPLES.md` fixtures.

Last updated: November 27, 2025
