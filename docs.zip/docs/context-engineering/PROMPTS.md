# Prompt Engineering — General Templates & Guidelines

This file defines base system and user messages, the canonical response schema, chunking rules, scoring thresholds, and validation guidance.

1) System message (base)
- Purpose: set role, strict output format, and constraints.

System:
You are a precise static/code-quality analysis assistant. When given a source code snippet and a detector name, inspect the code and return a JSON array of findings that exactly matches the schema described below. Do not provide any additional text. If there are no findings, return an empty JSON array: `[]`.

Constraints:
- Output must be valid JSON only (no markdown, no explanatory text).
- Use the exact keys and types in the schema.
- Keep messages compact to reduce tokens. If you cannot analyze due to missing context, return an empty array and include a `note` field inside the finding object describing what was missing.

2) Request / User message (generic)
- Variables: {language}, {filename}, {detector}, {code_chunk}, {context} (optional)

User:
Analyze the provided code chunk for "{detector}" in language `{language}` and file `{filename}`. Return findings following the schema.

3) Canonical output schema (JSON)
Return an array of 0..N finding objects:
[
  {
    "id": "<unique-id>",                 // string, unique per finding (e.g., file:loc:detector)
    "detector": "<detector-name>",      // matches requested detector
    "severity": "info|warning|error",   // severity mapping
    "message": "<short human-friendly summary>",
    "explanation": "<detailed explanation, remediation steps>",
    "start": { "line": <1-based>, "col": <1-based> },
    "end": { "line": <1-based>, "col": <1-based> },
    "confidence": <0.0-1.0>,              // float confidence score
    "metadata": { /* optional, detector-specific */ }
  }
]

Notes on fields
- `start` and `end` should be best-effort token/character positions (1-based line/col). If only approximate, mark `metadata.approximate: true`.
- `confidence` helps the extension filter low-value noise.

4) Token & chunking guidance
- Prefer sending functions/classes as units. If file size > token_limit, chunk by function/class boundaries or by N lines (suggest 200-400 lines per chunk depending on model).
- Provide minimal surrounding context: function signature + body + 3 lines before and after.
- Include a `context` field when cross-file or project-level info is required (e.g., class hierarchy).

5) Validation & anti-hallucination
- The backend must validate that the returned text is valid JSON before mapping to diagnostics.
- If the model returns non-JSON, gracefully retry up to 2 times, then fall back to a conservative empty result.
- Prefer using a model parameter that encourages JSON-only responses (e.g., system prompt + temperature=0.0).

6) Severity thresholds and mapping
- Example mapping suggestions for detectors:
  - `error` for critical security or correctness issues (SQL injection, dead-code that causes wrong behavior)
  - `warning` for code smells likely to cause maintenance burden (Large class, Long method)
  - `info` for low-risk stylistic issues (naming inconsistencies)

7) Aggregation & deduplication
- Detectors may run in parallel. Normalize findings by `id` (e.g., `filename:startline:endline:detector`) and deduplicate.

8) Few operational rules
- Keep prompt size minimal: include only the relevant code chunk. Supply the file path and language.
- Use per-detector templates for better precision (see `DETECTOR_PROMPTS.md`).

9) Example quick-call payload (JSON)
{
  "model": "gpt-4.1", 
  "messages": [
    {"role": "system", "content": "<system message above>"},
    {"role": "user", "content": "Analyze the provided code chunk for \"Long Method\" in language `javascript` and file `src/foo.js`. Code: ```function foo(){ ... }```"}
  ],
  "temperature": 0.0,
  "max_tokens": 800
}

10) Testing & metrics
- Track precision/recall with a labeled ground-truth dataset.
- Log examples where `confidence` < 0.6 for manual triage.


End of PROMPTS.md
