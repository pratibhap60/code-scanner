# Examples & Test Fixtures

This file contains compact code snippets and the expected JSON outputs to validate detectors quickly.

## Example 1 — Long Method (JavaScript)
Code (snippet):
function computeReport(data) {
  // imagine 200+ lines: many loops, nested conditionals, and repeated code
}

Expected (simplified):
[
  {
    "id": "src/utils/report.js:1:1:Long Method",
    "detector": "Long Method",
    "severity": "warning",
    "message": "Function `computeReport` is very long (approx. 220 lines).",
    "explanation": "Consider extracting smaller functions for distinct responsibilities: data aggregation, formatting, and IO. Splitting will improve readability and testability.",
    "start": {"line": 1, "col": 1},
    "end": {"line": 220, "col": 1},
    "confidence": 0.87,
    "metadata": {"lines": 220, "cyclomatic": 22}
  }
]

## Example 2 — Magic Number (Python)
Code:
if timeout > 300:
    retry()

Expected:
[
  {
    "id": "example.py:1:4:Magic Number",
    "detector": "Magic Numbers/Strings",
    "severity": "info",
    "message": "Literal `300` appears to be a magic number.",
    "explanation": "Extract this value to a named constant, e.g., `DEFAULT_TIMEOUT_SECONDS`, and reference it to clarify intent and simplify tuning.",
    "start": {"line": 1, "col": 12},
    "end": {"line": 1, "col": 15},
    "confidence": 0.75,
    "metadata": {"literal": 300, "suggestedConstantName": "DEFAULT_TIMEOUT_SECONDS"}
  }
]

## Example 3 — Long Parameter List (Java)
Code:
void createUser(String firstName, String lastName, String email, boolean isAdmin, String role, String tenantId) { ... }

Expected: one finding recommending grouping into `CreateUserRequest`.

## Running quick tests
- Copy snippet into a test fixture and call the detector via the backend's API endpoint.
- Validate the response JSON against the canonical schema.

End of EXAMPLES.md
