# Usage — Integrating Context Engineering into the VS Code Extension

This document explains where to plug prompt templates and how to convert AI outputs into VS Code diagnostics and code actions.

1) Where to put prompts
- Backend approach: keep prompts in `backend/services/ai.service.js`. Load templates from `docs/context-engineering/PROMPTS.md` and `DETECTOR_PROMPTS.md` (copy into JS string constants or JSON files).
- Extension-only approach: bundle sanitized prompts into `src/detectors/` and call hosted modelless or local LLM.

2) Mapping AI findings -> VS Code Diagnostic
- Use the `start` and `end` line/col fields to create `new vscode.Range(startLine-1, startCol-1, endLine-1, endCol-1)`.
- Map `severity` to `vscode.DiagnosticSeverity`:
  - `error` -> `Error`
  - `warning` -> `Warning`
  - `info` -> `Information`
- Attach `explanation` as `diagnostic.message` and include `metadata` in `diagnostic.relatedInformation` or `code`.

3) Code Actions (quick fixes)
- For certain detectors (magic numbers, long parameter list, duplicated code), provide suggested edits:
  - Magic number: extract to constant — create workspace edit inserting `const NAME = <value>` and replace occurrences.
  - Long parameter list: suggest creating a DTO — present an action that opens a small refactor snippet.
- Link code actions by `diagnostic.code` value and register a `CodeActionProvider`.

4) User configuration
- Provide VS Code settings to tune thresholds (e.g., `codeScanner.longMethod.thresholdLines`, `codeScanner.cyclomatic.threshold`).
- Allow enabling/disabling detectors.

5) UX considerations
- Debounce runs on file change (e.g., 800ms) and cancel pending requests when content changes.
- Keep non-blocking background scanning for heavy detectors; show a spinner or status bar message while scanning.

6) Logging & telemetry
- Log detector runtime, response times, errors, and counts of findings. Avoid logging raw user code; instead log hashes or anonymized metrics unless explicit consent is given.

7) Tests
- Use fixture files from `docs/context-engineering/EXAMPLES.md` to implement unit tests for the mapping layer (AI JSON -> diagnostics).

End of USAGE.md
