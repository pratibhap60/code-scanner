# Conversation & API Templates

This file describes recommended request/response payloads, streaming vs batch decisions, error handling, and sample server-side wiring for the backend `ai.service.js`.

1) Single-chunk API call (recommended for single function/class)
Request JSON (to your backend which forwards to model):
{
  "detector": "Long Method",
  "language": "javascript",
  "filename": "src/foo.js",
  "code": "function foo(){ ... }",
  "context": null,
  "modelOptions": { "temperature": 0.0, "max_tokens": 600 }
}

Response:
- `200` with content-type `application/json` and body: the validated JSON array of findings (see `PROMPTS.md` schema).

2) Batch/chunked flow (large files)
- Pre-scan file for boundaries (function/class). Break into chunks.
- For each chunk run per-detector prompt; collect findings.
- Merge/deduplicate findings and map coordinates to original file lines.

3) Streaming vs synchronous
- For fast UX in the editor, stream lightweight detectors first (naming, magic numbers, long parameter lists), then run heavy detectors (duplicated code, shotgun surgery) in background and update diagnostics as results arrive.

4) Error handling & retries
- On non-JSON output: retry with same prompt + "Return JSON only" reinforcement up to 2 times.
- On timeout or rate-limiting: exponential backoff (500ms * 2^n), up to 3 tries.
- If still failing, return safe fallback (empty array) and log the full model response for debugging.

5) Example server-side pseudo-code (Node.js)
- Accept request, determine chunking, call model, validate JSON, map to diagnostics, return.

6) Throttling & batching for IDE
- Limit model calls per file edit (e.g., debounce 800ms), batch detectors where appropriate, and cancel pending calls when a new edit supersedes them.

7) Security & privacy
- Do not send secrets or user credentials to third-party models. If the code contains suspected secrets, mask them before sending, and raise an info-level finding locally.

8) Output validation snippet (pseudo)
- Try JSON.parse(response)
- If parse fails, attempt to extract JSON block (regex) and parse
- If still fails, log and retry or return []

End of CONVERSATION_TEMPLATES.md
