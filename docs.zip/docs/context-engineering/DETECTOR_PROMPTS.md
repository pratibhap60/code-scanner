# Per-Detector Prompt Templates & Few-shot Examples

This file contains focused prompts for each code smell. Use these templates as the `user` content when calling the model. Each template enforces the canonical JSON schema defined in `PROMPTS.md`.

General rule: Call detectors individually for higher precision. If you need speed, run a light-weight combined prompt but expect noisier output.

---

## 1) Long Method
User template:
Analyze the code for the smell "Long Method". A Long Method is a function whose size or complexity negatively impacts readability or maintainability. Typical signs: > X lines (configurable), high cyclomatic complexity, many nested blocks, many local variables, many distinct responsibilities.

Few-shot example (user provides code):
- Input: a function with 220 lines and repeated sections.
- Expected JSON: one finding with severity `warning`, explanation listing refactor steps (extract method, add comments), confidence 0.85.

Metadata suggestions: include `metadata.lines`, `metadata.cyclomatic`

---

## 2) Large Class
User template:
Detect "Large Class": classes with many methods/fields, mixing unrelated responsibilities, or very high LOC. Provide where-to-split suggestions and candidate extracted classes.

Metadata: `metadata.methodCount`, `metadata.loc`

---

## 3) Long Parameter List
User template:
Detect functions or methods with many parameters (configurable threshold, e.g., >4). Suggest grouping into objects/DTOs and identify which parameters are related.

Metadata: `metadata.paramNames` (list)

---

## 4) Magic Numbers/Strings
User template:
Find literal numbers/strings used directly in code that likely should be constants. Exclude obvious constants (0,1) and language-specific idioms. Suggest constant names and proposed locations.

Metadata: `metadata.literal`, `metadata.suggestedConstantName`

---

## 5) God Object
User template:
Detect objects/classes that centralize too many responsibilities or hold global state. Provide a short plan to split responsibilities and list candidate new classes/modules.

Metadata: `metadata.responsibilities`

---

## 6) Duplicated Code
User template:
Detect duplicated or near-duplicated code blocks within the provided file or across the provided `context` files. Provide normalized snippet pair references and a refactor recommendation (extract method/module).

Metadata: `metadata.duplicateGroups` (array of {locations, similarity})

---

## 7) Primitive Obsession
User template:
Detect when primitives (strings/ints/bools) are overused for domain concepts that would benefit from small structs/classes or enums. Suggest domain types.

Metadata: `metadata.affectedFunctions`

---

## 8) Feature Envy
User template:
Detect methods that access more data/behavior from other classes than their own, suggesting they belong elsewhere.

Metadata: `metadata.accessedFields` (by-other-class)

---

## 9) Comment Smell
User template:
Detect excessive, redundant, or outdated comments. Flag comments that restate the code or contradict it. Suggest removing or updating.

Metadata: `metadata.commentText`

---

## 10) Shotgun Surgery
User template:
Detect places where a single conceptual change requires edits across many files or locations. Provide the list of locations and a consolidation plan.

Metadata: `metadata.locations`

---

## 11) Dead Code
User template:
Detect unused functions, unreachable branches, or variables that are declared but never used. Provide safe-removal suggestions.

Metadata: `metadata.usageCount`

---

## 12) Cyclomatic Complexity
User template:
Compute or approximate cyclomatic complexity for functions/methods. Flag anything above threshold (configurable, e.g., > 10). Offer refactor suggestions.

Metadata: `metadata.cyclomatic`

---

## 13) Inconsistent Naming
User template:
Detect naming inconsistencies (snake_case vs camelCase, misleading names, abbreviations). Suggest an alternative and reasoning.

Metadata: `metadata.currentName`, `metadata.suggestedName`

---

## 14) Poor Error Handling
User template:
Detect broad catch-blocks, swallowed errors, inconsistent error propagation, or missing error checks. Recommend best-practices (specific catches, rethrow with context).

Metadata: `metadata.catchLocation`

---

## 15) Excessive If/Else / Deep Nesting
User template:
Detect deeply nested control flow (> N nesting, e.g., 4), large if/else chains. Suggest early returns, guard clauses, or polymorphism.

Metadata: `metadata.maxNestingDepth`

---

## 16) Switch Statements over polymorphism
User template:
Detect switch/case constructs that branch on types/keys and recommend polymorphism or strategy pattern.

Metadata: `metadata.cases`

---

## 17) Data Clumps
User template:
Detect groups of parameters or fields that repeatedly occur together; suggest grouping into a single data structure.

Metadata: `metadata.clumpFields`

---

Tips for few-shot examples
- Provide 1-2 positive examples (where the smell exists) and 1 negative example (where it doesn't) per detector.
- Show expected JSON outputs for each example to guide the model.

End of DETECTOR_PROMPTS.md
